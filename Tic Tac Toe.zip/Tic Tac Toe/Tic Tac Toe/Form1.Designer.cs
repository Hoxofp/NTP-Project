﻿namespace Tic_Tac_Toe
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			button1 = new Button();
			button2 = new Button();
			button3 = new Button();
			button4 = new Button();
			button5 = new Button();
			button6 = new Button();
			button7 = new Button();
			button8 = new Button();
			button9 = new Button();
			label1 = new Label();
			label2 = new Label();
			button10 = new Button();
			GameTimer = new System.Windows.Forms.Timer(components);
			SuspendLayout();
			// 
			// button1
			// 
			button1.Location = new Point(64, 67);
			button1.Name = "button1";
			button1.Size = new Size(147, 138);
			button1.TabIndex = 0;
			button1.UseVisualStyleBackColor = true;
			button1.Click += PlayerClickButton;
			// 
			// button2
			// 
			button2.Location = new Point(217, 67);
			button2.Name = "button2";
			button2.Size = new Size(147, 138);
			button2.TabIndex = 1;
			button2.UseVisualStyleBackColor = true;
			button2.Click += PlayerClickButton;
			// 
			// button3
			// 
			button3.Location = new Point(370, 67);
			button3.Name = "button3";
			button3.Size = new Size(147, 138);
			button3.TabIndex = 2;
			button3.UseVisualStyleBackColor = true;
			button3.Click += PlayerClickButton;
			// 
			// button4
			// 
			button4.Location = new Point(64, 211);
			button4.Name = "button4";
			button4.Size = new Size(147, 138);
			button4.TabIndex = 5;
			button4.UseVisualStyleBackColor = true;
			button4.Click += PlayerClickButton;
			// 
			// button5
			// 
			button5.Location = new Point(217, 211);
			button5.Name = "button5";
			button5.Size = new Size(147, 138);
			button5.TabIndex = 4;
			button5.UseVisualStyleBackColor = true;
			button5.Click += PlayerClickButton;
			// 
			// button6
			// 
			button6.Location = new Point(370, 211);
			button6.Name = "button6";
			button6.Size = new Size(147, 138);
			button6.TabIndex = 3;
			button6.UseVisualStyleBackColor = true;
			button6.Click += PlayerClickButton;
			// 
			// button7
			// 
			button7.Location = new Point(64, 355);
			button7.Name = "button7";
			button7.Size = new Size(147, 138);
			button7.TabIndex = 8;
			button7.UseVisualStyleBackColor = true;
			button7.Click += PlayerClickButton;
			// 
			// button8
			// 
			button8.Location = new Point(217, 355);
			button8.Name = "button8";
			button8.Size = new Size(147, 138);
			button8.TabIndex = 7;
			button8.UseVisualStyleBackColor = true;
			button8.Click += PlayerClickButton;
			// 
			// button9
			// 
			button9.Location = new Point(370, 355);
			button9.Name = "button9";
			button9.Size = new Size(147, 138);
			button9.TabIndex = 6;
			button9.UseVisualStyleBackColor = true;
			button9.Click += PlayerClickButton;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Montserrat", 15F, FontStyle.Regular, GraphicsUnit.Point);
			label1.ForeColor = Color.FromArgb(0, 192, 0);
			label1.Location = new Point(12, 10);
			label1.Name = "label1";
			label1.Size = new Size(194, 35);
			label1.TabIndex = 9;
			label1.Text = "Player's Wins: ";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Montserrat", 15F, FontStyle.Regular, GraphicsUnit.Point);
			label2.ForeColor = Color.Red;
			label2.Location = new Point(497, 10);
			label2.Name = "label2";
			label2.Size = new Size(237, 35);
			label2.TabIndex = 10;
			label2.Text = "Computer's Wins:";
			// 
			// button10
			// 
			button10.Location = new Point(585, 448);
			button10.Name = "button10";
			button10.Size = new Size(174, 45);
			button10.TabIndex = 11;
			button10.Text = "Restart Game";
			button10.UseVisualStyleBackColor = true;
			button10.Click += RestartGame;
			// 
			// GameTimer
			// 
			GameTimer.Interval = 1000;
			GameTimer.Tick += ComputerMove;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(807, 528);
			Controls.Add(button10);
			Controls.Add(label2);
			Controls.Add(label1);
			Controls.Add(button7);
			Controls.Add(button8);
			Controls.Add(button9);
			Controls.Add(button4);
			Controls.Add(button5);
			Controls.Add(button6);
			Controls.Add(button3);
			Controls.Add(button2);
			Controls.Add(button1);
			Name = "Form1";
			Text = "Form1";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button button1;
		private Button button2;
		private Button button3;
		private Button button4;
		private Button button5;
		private Button button6;
		private Button button7;
		private Button button8;
		private Button button9;
		private Label label1;
		private Label label2;
		private Button button10;
		private System.Windows.Forms.Timer GameTimer;
	}
}
